#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
process_trace_v23.py

✅ 修复“标样检验只剩 Element 列（整列空白）”：
原因：新标样样.docx 的标题行格式变了，v22 过于严格，没识别到任何标样段落 -> refs 为空，
从而 std_present 为空，标样检验只会剩 Element。

v23 改动：
1) 标样参考解析：同时支持【段落】+【表格】两种（自动检测）
2) 标样标题识别更宽松：只要段落里出现 BHVO-2/GSR-1/... 就认为进入该标样段（不再要求含 Info/括号）
3) 元素行识别更宽松：支持 "Li" / "6 Li" / " 47 Ti " 等，取元素符号
4) 在运行时打印解析到的标样列表（refs.keys()）以及本次数据中出现的标样列表（std_present），方便你核对

参考值选择仍按 v22 的逻辑：
- 同一元素行：解析 overall 与 compiled
- overall 离谱 -> 用 compiled；否则用 overall
- 若只有一种则用那一种
输出：范围 "lo - hi"，单值 "value"

其它（FI/重复样/输出sheet）保持不变。

依赖：numpy pandas openpyxl python-docx
"""

import argparse
import re
from typing import Dict, List, Tuple, Any, Optional

import numpy as np
import pandas as pd
import openpyxl
from openpyxl import Workbook
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.styles import PatternFill
from docx import Document

META_COLS = ["样品","拒绝","数据文件","采集日期时间","类型","级别","样品名称"]
YELLOW = PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid")

STD_CODE_RE = re.compile(r'\b([A-Z]{2,6}-?\d+(?:-\d+)?[A-Z]?)\b')
ELEM_ONLY_RE = re.compile(r'^\s*([A-Z][a-z]?)\s*$')
ELEM_WITH_MASS_RE = re.compile(r'^\s*(\d+)\s*([A-Z][a-z]?)\s*$')

RANGE_RE = re.compile(r'(?<!\d)([\d\.]+)\s*-\s*([\d\.]+)(?!\d)')
SINGLE_RE = re.compile(r'(?<!\d)([\d\.]+)(?!\d)')
COMPILED_RANGE_RE = re.compile(r'compiled:\s*([\d\.]+)\s*-\s*([\d\.]+)', re.I)
COMPILED_SINGLE_RE = re.compile(r'compiled:\s*([\d\.]+)', re.I)

def norm_id(x: Any) -> str:
    if x is None: return ""
    s = str(x).strip()
    try:
        xf = float(s)
        if xf.is_integer():
            return str(int(xf))
    except Exception:
        pass
    return s

def to_number(x: Any) -> Optional[float]:
    if x is None: return None
    if isinstance(x, (int, float, np.number)):
        if isinstance(x, float) and (np.isnan(x) or np.isinf(x)): return None
        return float(x)
    s = str(x).strip()
    if s == "" or s.startswith("<") or s.upper() in {"NA","N/A","ND","N.D."}: return None
    try:
        return float(s)
    except Exception:
        return None

def format_value(x: Any) -> str:
    try:
        if x is None: return "-"
        if isinstance(x, str): return "-" if x.strip().startswith("<") else x
        xv = float(x)
        if np.isnan(xv) or np.isinf(xv) or xv < 0: return "-"
        if xv >= 100: return f"{xv:.0f}"
        if xv >= 10: return f"{xv:.1f}"
        return f"{xv:.2f}"
    except Exception:
        return "-"

def pct_int(x: float) -> str:
    return str(int(round(x)))

def is_blank_sample_name(name: str) -> bool:
    s = (name or "").strip().lower()
    return ("空白" in s) or ("blank" in s)

def std_code_from_name(name: str) -> Optional[str]:
    if not name: return None
    m = STD_CODE_RE.search(str(name))
    return m.group(1) if m else None

def base_name(name: str) -> str:
    return re.sub(r'[Rr]$', '', str(name).strip())

def is_repeat_name(name: str) -> bool:
    return bool(re.search(r'[Rr]$', str(name).strip()))

def parse_sendlist(wb_val: openpyxl.Workbook, sheet_name: str="送样单") -> Dict[str, Dict[str, Any]]:
    ws = wb_val[sheet_name]
    headers = [ws.cell(1,c).value for c in range(1, ws.max_column+1)]
    col_index = {h:i+1 for i,h in enumerate(headers) if h}
    need = ["溶样弹编号","样号","倍数/1000"]
    for n in need:
        if n not in col_index:
            raise ValueError(f'送样单缺少列: {n}')
    mapping: Dict[str, Dict[str, Any]] = {}
    for r in range(2, ws.max_row+1):
        vid = norm_id(ws.cell(r, col_index["溶样弹编号"]).value)
        if not vid: continue
        mapping[vid] = {"sample": ws.cell(r, col_index["样号"]).value,
                        "dil": ws.cell(r, col_index["倍数/1000"]).value}
    return mapping

def parse_concentration_sheet(wb_val: openpyxl.Workbook, sheet_name: str="浓度") -> Tuple[pd.DataFrame, List[str]]:
    ws = wb_val[sheet_name]
    header1 = [ws.cell(1,c).value for c in range(1, ws.max_column+1)]
    header2 = [ws.cell(2,c).value for c in range(1, ws.max_column+1)]

    elem_cols: List[str] = []
    elem_col_idx: List[int] = []
    for c in range(8, ws.max_column+1):
        h2 = header2[c-1]
        if isinstance(h2, str) and ("浓度" in h2) and ("ppb" in h2):
            h1 = header1[c-1]
            if not isinstance(h1, str): continue
            m = re.search(r'(\d+)\s*([A-Za-z]+)', h1)
            colname = f"{m.group(1)} {m.group(2)}" if m else h1.strip()
            if colname in elem_cols:
                k = 2
                while f"{colname}_{k}" in elem_cols: k += 1
                colname = f"{colname}_{k}"
            elem_cols.append(colname); elem_col_idx.append(c)

    records: List[Dict[str, Any]] = []
    for r in range(3, ws.max_row+1):
        if ws.cell(r, 7).value is None and ws.cell(r,1).value is None: continue
        row: Dict[str, Any] = {}
        for i, k in enumerate(META_COLS, start=1):
            row[k] = ws.cell(r,i).value
        for colname, c in zip(elem_cols, elem_col_idx):
            row[colname] = ws.cell(r,c).value
        records.append(row)
    return pd.DataFrame(records), elem_cols

def write_sheet(out_wb: openpyxl.Workbook, name: str, df: pd.DataFrame):
    if name in out_wb.sheetnames:
        out_wb.remove(out_wb[name])
    ws = out_wb.create_sheet(name)
    for r in dataframe_to_rows(df, index=False, header=True):
        ws.append(r)
    ws.freeze_panes = "A2"
    return ws

def build_targets(elem_cols: List[str]) -> Dict[str, float]:
    targets={}
    for col in elem_cols:
        m = re.match(r'\d+\s+([A-Za-z]+)', col)
        sym = m.group(1) if m else col
        targets[col] = 20.0 if sym == "Ti" else 10.0
    return targets

def col_symbol(col: str) -> str:
    m = re.match(r'\d+\s+([A-Za-z]+)', col)
    return m.group(1) if m else col.strip()

def format_ref(lo: float, hi: float) -> str:
    return f"{lo}" if lo == hi else f"{lo} - {hi}"

def parse_overall_and_compiled(text: str) -> Tuple[Optional[Tuple[float,float]], Optional[Tuple[float,float]]]:
    t = (text or "").replace('\xa0',' ').replace('–','-').replace('—','-')
    compiled = None
    m = COMPILED_RANGE_RE.search(t)
    if m:
        compiled = (float(m.group(1)), float(m.group(2)))
    else:
        m = COMPILED_SINGLE_RE.search(t)
        if m:
            v=float(m.group(1)); compiled=(v,v)

    head = t
    cm = re.search(r'\(\s*compiled:', t, flags=re.I)
    if cm:
        head = t[:cm.start()]
    overall = None
    m = RANGE_RE.search(head)
    if m:
        overall = (float(m.group(1)), float(m.group(2)))
    else:
        m = SINGLE_RE.search(head)
        if m:
            v=float(m.group(1)); overall=(v,v)
    return overall, compiled

def is_insane_range(rng: Tuple[float,float]) -> bool:
    lo,hi=rng
    if hi > 1e6: return True
    if lo != 0 and (hi/lo > 50): return True
    base=max(1.0, abs(lo))
    if abs(hi-lo) > 100*base: return True
    return False

def choose_ref(overall, compiled):
    if overall is None and compiled is None: return None
    if compiled is None: return overall
    if overall is None: return compiled
    return compiled if is_insane_range(overall) else overall

def parse_reference_docx(docx_path: str) -> Dict[str, Dict[str, Tuple[float,float]]]:
    """
    兼容：段落式 + 表格式
    """
    doc = Document(docx_path)
    refs: Dict[str, Dict[str, Tuple[float,float]]] = {}

    # --- 1) paragraph-based ---
    paras = [p.text.strip() for p in doc.paragraphs if p.text and p.text.strip()]
    current_std = None
    i = 0
    while i < len(paras):
        line = paras[i].replace('\xa0',' ')
        std = std_code_from_name(line)
        # 宽松：只要出现标准编号，就切换
        if std and not ELEM_ONLY_RE.match(line) and not ELEM_WITH_MASS_RE.match(line):
            current_std = std
            refs.setdefault(current_std, {})
            i += 1
            continue

        if current_std:
            m1 = ELEM_ONLY_RE.match(line)
            m2 = ELEM_WITH_MASS_RE.match(line)
            if (m1 or m2) and (i+1) < len(paras):
                elem = (m1.group(1) if m1 else m2.group(2))
                val_line = paras[i+1].replace('\xa0',' ')
                overall, compiled = parse_overall_and_compiled(val_line)
                picked = choose_ref(overall, compiled)
                if picked:
                    refs[current_std][elem] = picked
                i += 2
                continue
        i += 1

    # --- 2) table-based fallback (if any tables exist) ---
    for tbl in doc.tables:
        # detect std by scanning first two rows
        scan=[]
        for ridx in range(min(2, len(tbl.rows))):
            scan += [c.text.strip().replace('\xa0',' ') for c in tbl.rows[ridx].cells if c.text]
        std = std_code_from_name(" ".join(scan))
        if not std: 
            continue
        refs.setdefault(std, {})
        # find element column
        ncols = len(tbl.rows[0].cells)
        elem_col = 0
        best=-1
        for ci in range(ncols):
            hits=0
            for row in tbl.rows[1:]:
                t=row.cells[ci].text.strip()
                if ELEM_ONLY_RE.match(t) or ELEM_WITH_MASS_RE.match(t):
                    hits += 1
            if hits>best:
                best=hits; elem_col=ci
        for row in tbl.rows[1:]:
            cells=[c.text.strip().replace('\xa0',' ') for c in row.cells]
            if len(cells) <= elem_col: continue
            et = cells[elem_col].strip()
            m1=ELEM_ONLY_RE.match(et); m2=ELEM_WITH_MASS_RE.match(et)
            if not (m1 or m2): continue
            elem = (m1.group(1) if m1 else m2.group(2))
            # combine the rest cells as value line
            val_line=" ".join([cells[j] for j in range(len(cells)) if j!=elem_col])
            overall, compiled = parse_overall_and_compiled(val_line)
            picked = choose_ref(overall, compiled)
            if picked and elem not in refs[std]:
                refs[std][elem]=picked

    return refs

def build_fi_calc_sheet(conc_df: pd.DataFrame, elem_cols: List[str], targets: Dict[str, float]) -> pd.DataFrame:
    rows=[]; inserted=False; fi_n=0
    for _, r in conc_df.iterrows():
        sam=str(r.get("样品名称") if r.get("样品名称") is not None else "")
        if (not inserted) and sam.upper()=="QC":
            tr={"样品名称":"目标浓度"}
            for c in elem_cols: tr[c]=targets[c]
            rows.append(tr); inserted=True
        rr={"样品名称": sam}
        for c in elem_cols:
            n=to_number(r.get(c)); rr[c]=n if n is not None else "-"
        rows.append(rr)
        if sam.upper()=="QC":
            fi_n += 1
            fr={"样品名称": f"FI{fi_n}"}
            for c in elem_cols:
                m=to_number(r.get(c)); fr[c]="-" if m is None else (m/targets[c])
            rows.append(fr)
    if not inserted:
        tr={"样品名称":"目标浓度"}
        for c in elem_cols: tr[c]=targets[c]
        rows.insert(0,tr)
    return pd.DataFrame(rows)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("-o","--output", default=None)
    ap.add_argument("--ref_docx", required=True)
    ap.add_argument("--sheet_send", default="送样单")
    ap.add_argument("--sheet_conc", default="浓度")
    args=ap.parse_args()

    in_path=args.input
    out_path=args.output or (re.sub(r"\.xlsx?$","",in_path)+"_自动计算.xlsx")

    wb_val=openpyxl.load_workbook(in_path, data_only=True)
    send_map=parse_sendlist(wb_val, args.sheet_send)
    conc_df, elem_cols = parse_concentration_sheet(wb_val, args.sheet_conc)
    targets=build_targets(elem_cols)

    refs=parse_reference_docx(args.ref_docx)
    print("[INFO] 参考文档解析到的标样：", ", ".join(sorted(refs.keys())) if refs else "(空)")

    # aligned raw
    raw=[]
    for _, r in conc_df.iterrows():
        rid=norm_id(r.get("样品名称"))
        row={"run_id": rid, "raw_name": r.get("样品名称")}
        for c in elem_cols:
            n=to_number(r.get(c)); row[c]=n if n is not None else "-"
        raw.append(row)

    # FI correction
    corrected=[row.copy() for row in raw]
    prev_fi=None; buf=[]
    def fi_from_qc(qc):
        fi={}
        for c in elem_cols:
            m=to_number(qc.get(c)); fi[c]=None if m is None else (m/targets[c])
        return fi
    def apply(val,f):
        m=to_number(val)
        if m is None or f is None or f==0: return "-"
        return m/float(f)

    for idx, row in enumerate(raw):
        if str(row["run_id"]).isdigit(): buf.append(idx)
        if str(row["raw_name"]).upper()=="QC":
            fi_curr=fi_from_qc(row)
            if prev_fi is None:
                for ridx in buf:
                    for c in elem_cols: corrected[ridx][c]=apply(raw[ridx][c], fi_curr.get(c))
            else:
                n=len(buf); prev_n=max(1,n//2)
                for ridx in buf[:prev_n]:
                    for c in elem_cols: corrected[ridx][c]=apply(raw[ridx][c], prev_fi.get(c))
                for ridx in buf[prev_n:]:
                    for c in elem_cols: corrected[ridx][c]=apply(raw[ridx][c], fi_curr.get(c))
            buf=[]; prev_fi=fi_curr
    if buf and prev_fi is not None:
        for ridx in buf:
            for c in elem_cols: corrected[ridx][c]=apply(raw[ridx][c], prev_fi.get(c))

    # FI校正 sheet
    fi_rows=[]; fi_sep=0
    for idx, r in conc_df.iterrows():
        rid=norm_id(r.get("样品名称")); raw_name=r.get("样品名称")
        if str(raw_name).upper()=="QC":
            fi_sep += 1
            qc={"样品":"QC","样品标号":""}
            fi={"样品":f"FI{fi_sep}","样品标号":""}
            for c in elem_cols: qc[c]=fi[c]=""
            fi_rows += [qc, fi]; continue
        if str(rid).isdigit():
            info=send_map.get(rid,{})
            sname=info.get("sample", rid)
            out={"样品":sname,"样品标号":rid}
            for c in elem_cols: out[c]=corrected[idx][c]
            fi_rows.append(out)
    fi_df=pd.DataFrame(fi_rows, columns=["样品","样品标号"]+elem_cols)

    # 稀释倍数 & 有效位数
    dil_rows=[]; sig_rows=[]
    for idx, r in conc_df.iterrows():
        rid=norm_id(r.get("样品名称"))
        if not str(rid).isdigit(): continue
        info=send_map.get(rid,{})
        sname=info.get("sample", rid)
        dil=info.get("dil", None)
        drow={"样品":sname,"样品标号":rid}
        srow={"样品":sname,"样品标号":rid}
        for c in elem_cols:
            v=corrected[idx][c]
            if v=="-" or dil is None or isinstance(dil,str):
                dv="-"
            else:
                dv=float(v)*float(dil)
            drow[c]=dv; srow[c]=format_value(dv)
        dil_rows.append(drow); sig_rows.append(srow)
    dil_df=pd.DataFrame(dil_rows, columns=["样品","样品标号"]+elem_cols)
    sig_df=pd.DataFrame(sig_rows, columns=["样品","样品标号"]+elem_cols)

    # 标样检验
    std_present=[]
    for s in dil_df["样品"].astype(str).tolist():
        sc=std_code_from_name(s)
        if sc and sc in refs and sc not in std_present:
            std_present.append(sc)
    print("[INFO] 数据中可用于标样检验的标样：", ", ".join(std_present) if std_present else "(空)")

    dil_num=dil_df.copy()
    for c in elem_cols:
        dil_num[c]=dil_num[c].apply(to_number)

    check_rows=[]
    for ecol in elem_cols:
        sym=col_symbol(ecol)
        rr={"Element":ecol}
        for std in std_present:
            vals=[]
            for _, row in dil_num.iterrows():
                if std_code_from_name(str(row["样品"])) == std:
                    v=row.get(ecol)
                    if v is not None: vals.append(float(v))
            meas=float(np.mean(vals)) if vals else ""
            ref=refs.get(std,{}).get(sym)
            rr[std]=meas
            rr[f"{std}_ref"]=format_ref(ref[0],ref[1]) if ref else ""
        check_rows.append(rr)
    cols=["Element"]
    for std in std_present:
        cols += [std, f"{std}_ref"]
    std_df=pd.DataFrame(check_rows, columns=cols)

    # 重复样检验（略：与之前一致）
    rep_rows=[]; main_by={}; fi_counter=0
    def add_rep(label, run_id, name, vals):
        rr={"标记":label,"样品名称":name,"序号":run_id}
        for c in elem_cols: rr[c]=vals.get(c,"-")
        rep_rows.append(rr)

    for idx, r in conc_df.iterrows():
        rid=norm_id(r.get("样品名称")); raw_name=r.get("样品名称")
        if str(raw_name).upper()=="QC":
            fi_counter += 1
            add_rep("QC","","",{c:"" for c in elem_cols})
            add_rep(f"FI{fi_counter}","","",{c:"" for c in elem_cols})
            continue
        if str(rid).isdigit():
            info=send_map.get(rid,{})
            sname=str(info.get("sample", rid)).strip()
            vals={c: corrected[idx][c] for c in elem_cols}
            add_rep("", rid, sname, vals)
            if is_blank_sample_name(sname): continue
            base=base_name(sname); explicit=is_repeat_name(sname)
            if explicit or (base in main_by):
                main=main_by.get(base)
                if main:
                    avg_vals={}; e1={}; e2={}
                    for c in elem_cols:
                        n_main=to_number(main.get(c,"-")) if main.get(c,"-")!="-" else None
                        n_rep=to_number(vals.get(c,"-")) if vals.get(c,"-")!="-" else None
                        if n_main is None or n_rep is None:
                            avg_vals[c]=e1[c]=e2[c]="-"; continue
                        avg=(n_main+n_rep)/2.0
                        avg_vals[c]=avg
                        e1[c]="-" if avg==0 else pct_int((n_main-avg)/avg*100.0)
                        e2[c]="-" if n_rep==0 else pct_int((n_main-n_rep)/n_rep*100.0)
                    add_rep("Average","","",avg_vals)
                    add_rep("误差百分比1(%)","","",e1)
                    add_rep("误差百分比2(%)","","",e2)
                if not explicit: main_by[base]=vals
            else:
                main_by[base]=vals
    rep_df=pd.DataFrame(rep_rows)

    # 最终结果矩阵
    final=pd.DataFrame({"元素": elem_cols})
    for _, r in sig_df.iterrows():
        final[str(r["样品"])]=r[elem_cols].values

    fi_calc_df=build_fi_calc_sheet(conc_df, elem_cols, targets)

    out_wb=Workbook()
    out_wb.remove(out_wb.active)
    try:
        send_df=pd.read_excel(in_path, sheet_name=args.sheet_send)
    except Exception:
        send_df=pd.DataFrame()

    write_sheet(out_wb,"送样单",send_df)
    write_sheet(out_wb,"浓度(提取)",conc_df)
    write_sheet(out_wb,"计算校正因子FI",fi_calc_df)
    write_sheet(out_wb,"FI校正",fi_df)
    write_sheet(out_wb,"重复样检验",rep_df)
    write_sheet(out_wb,"稀释倍数",dil_df)
    write_sheet(out_wb,"有效位数",sig_df)
    ws_std=write_sheet(out_wb,"标样检验",std_df)
    write_sheet(out_wb,"最终结果",final)

    # highlight
    header=[c.value for c in ws_std[1]]
    idx_map={h:i+1 for i,h in enumerate(header) if h}
    for std in std_present:
        c_meas=idx_map.get(std); c_ref=idx_map.get(f"{std}_ref")
        if not c_meas or not c_ref: continue
        for r in range(2, ws_std.max_row+1):
            meas=to_number(ws_std.cell(r,c_meas).value)
            if meas is None: continue
            ref_txt=str(ws_std.cell(r,c_ref).value or "").strip()
            m=re.match(r'^([\d\.]+)\s*-\s*([\d\.]+)$', ref_txt)
            if m:
                lo,hi=float(m.group(1)), float(m.group(2))
                if meas<lo or meas>hi:
                    ws_std.cell(r,c_meas).fill=YELLOW
            else:
                v=to_number(ref_txt)
                if v is not None and meas != v:
                    ws_std.cell(r,c_meas).fill=YELLOW

    out_wb.save(out_path)
    print(out_path)

if __name__=="__main__":
    main()
